import { AsyncPipe, JsonPipe } from '@angular/common';
import { Component, inject } from '@angular/core';
import { ApiService } from './core/services/api.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [AsyncPipe, JsonPipe],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {

  apiService = inject(ApiService);

  data$ = this.apiService.getTodo();
  token = '';

  ngOnInit() {
    const req = { USER_ID: "E28995259H" };
    this.apiService.getToken(req).subscribe(res => {
      console.log('res', res);
      this.token = res.TOKEN;
    })
  }
}
