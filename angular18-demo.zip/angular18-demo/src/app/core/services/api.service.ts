import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';

interface GetTokenTranrq {
  /** 帳號 */
  USER_ID: string;
}

interface MwHeaderReq {
  TXNSEQ: string;
}

interface BaseRequest<T> {
  MWHEADER: MwHeaderReq;
  TRANRQ?: T;
}

interface BaseResponse<T> {
  MWHEADER: MwHeaderRes;
  TRANRS: T;
}

interface MwHeaderRes {
  RETURNCODE: string;
  RETURNDESC: string;
  TXNSEQ: string;
}

class GetTokenRes {
  TOKEN = '';

  /**
   * 建構子
   * @param {*} res - 後端傳的參數
   * @memberof GetTokenRes
   */
  constructor(res?: any) {
    if (!res) {
      return;
    }
    this.TOKEN = res?.TOKEN || '';
  }
}

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  http = inject(HttpClient);

  samlPrefix = '/saml-svc'


  baseRequest: BaseRequest<unknown> = {
    MWHEADER: {
      TXNSEQ: '12345678901234'
    }
  };

  getTodo() {
    return this.http.get('https://jsonplaceholder.typicode.com/todos/1');
  }

  getToken(tranrq: GetTokenTranrq): Observable<GetTokenRes> {
    const model: BaseRequest<GetTokenTranrq> = Object.assign({ TRANRQ: tranrq }, this.baseRequest);
    const url = this.samlPrefix + '/v1/saml/getToken';
    return this.http.post<BaseResponse<GetTokenRes>>(url, model).pipe(map(res => new GetTokenRes(res.TRANRS)));
  }
}
